<?php
ob_start(); // Turns on output buffering
session_start();

date_default_timezone_set("Europe/London");
?>