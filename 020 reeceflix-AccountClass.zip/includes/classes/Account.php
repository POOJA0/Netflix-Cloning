<?php
class Account {

    private $con;

    public function __construct($con) {
        $this->con = $con;
    }

}
?>